# example-next（Next 代际示例插件）

这是一个 **Next 架构（目录式）** 的示例插件，用于展示：

- 插件目录结构与 `manifest.json` 规范
- 基础接口（文本/JSON）
- 数据表 + 后台数据管理（`admin.resources`）
- 数据编辑页的资源级“数据概览卡片”（`admin.resources[].overview.cards`）
- 字段类型与组件能力（`text/number/enum/boolean + switch/date-or-iso`）

## 1. 目录结构

```text
apis/
  example-next/
    index.js
    manifest.json
    README.md
```

- `index.js`
  - Express Router 入口
  - 可选：数据库建表、统计接口等
- `manifest.json`
  - 插件元信息（name/title/type/author/version）
  - 后台数据管理声明（admin.resources）
  - 资源级概览卡片（admin.resources[].overview.cards）

## 2. 插件对外接口（HTTP）

假设服务把 `apis/<pluginName>` 挂载到 `/apis/<pluginName>`：

- `GET /apis/example-next/`
  - 返回文本：`Hello World! (Next plugin)`

- `GET /apis/example-next/json`
  - 返回 JSON：

```json
{
  "msg": "ok",
  "status": 200,
  "data": {
    "plugin": "example-next",
    "version": "v1.0",
    "now": "..."
  }
}
```

- `GET /apis/example-next/summary`
  - 用于后台数据编辑页的“数据概览卡片”
  - 返回示例统计（总数/置顶数/完成数）

## 3. 数据表与初始化

本示例插件会在启动后尝试创建数据表：

- 表名：`example_next_items`
- 字段：
  - `id` (INT, PK, auto increment)
  - `title` (VARCHAR)
  - `content` (TEXT)
  - `status` (INT, 0/1)
  - `pinned` (TINYINT(1), 0/1)
  - `category` (VARCHAR)
  - `created_at` (VARCHAR)

具体建表逻辑在 `index.js -> ensureExampleTables()`。

## 4. 后台数据管理（admin.resources）

在 `manifest.json` 中声明：

- `admin.resources[].table`
  - 对应 MySQL 表名
- `admin.resources[].primaryKey`
  - 主键字段（默认 `id`）
- `admin.resources[].permissions`
  - 支持：`list/create/update/delete`
- `admin.resources[].fields`
  - 声明字段类型、label、只读、枚举等

后台相关路由由 `@core/adminDataApi.js` 自动提供（无需插件自己写 CRUD）：

- `GET /admin/api/data/:plugin/:resource?limit=..&offset=..`
- `POST /admin/api/data/:plugin/:resource`
- `PUT /admin/api/data/:plugin/:resource/:id`
- `DELETE /admin/api/data/:plugin/:resource/:id?confirm=true`

## 5. 数据编辑页的“资源级概览卡片”（overview.cards）

本项目已支持在数据编辑页：

- `/admin/data/<plugin>/<resource>`（即前端 `/data/[plugin]/[resource]`）

展示插件注册的概览卡片。

### 5.1 配置位置（资源级）

配置写在：

- `manifest.json -> admin.resources[].overview.cards`

示例：

```json
"overview": {
  "cards": [
    {
      "id": "summary",
      "title": "示例统计",
      "endpoint": "/apis/example-next/summary"
    }
  ]
}
```

### 5.2 数据来源

此方案为“前端直连插件 endpoint”：

- 前端先调用：
  - `GET /admin/api/data/:plugin/:resource/overview`
  - 拿到 cards 配置
- 然后对每个 card：
  - `fetch(card.endpoint)`

所以：

- `endpoint` 必须能被浏览器访问
- 必须返回 JSON（至少能 `resp.json()`）

## 6. 字段类型 / 组件能力（fields 规范示例）

本示例覆盖了以下字段能力：

- `string`
  - 普通输入框
- `text`
  - 长文本 Textarea（`def.type === "text"` 或字段名命中 description/content 等）
- `number`
  - 数字输入；若带 `enum`，会用 Select，且提交会自动 `Number(...)`
- `enum`
  - Select 组件渲染
- `boolean` + `widget: "switch"`
  - Switch（开关）渲染
- `format: "date-or-iso"`
  - 当前 UI 仅做输入，不做强校验；用于提示 `YYYY-MM-DD` 或 ISO8601

示例字段定义（片段）：

```json
"status": { "type": "number", "label": "状态", "required": true, "enum": [0, 1] },
"pinned": { "type": "boolean", "label": "置顶", "widget": "switch" },
"content": { "type": "text", "label": "内容" }
```

## 7. 规范与注意事项

- `manifest.json` 的 `name` 必须与目录名一致（建议一致），且用于路由挂载。
- `admin.resources[].table/primaryKey/fields` 中的字段名必须满足：
  - 仅允许 `a-zA-Z0-9_`（由 `@core/adminDataApi.js` 做安全校验）
- 资源级概览卡片 `endpoint` 建议返回：
  - `{ msg, status, data }` 或 `{ ok, data }`
  - 当前 UI 会优先取 `payload.data` 作为展示对象

